import React, { useState } from "react";
import dayjs from "dayjs";
import "dayjs/locale/ru";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

import DateRangeFilter from "./DateRangeFilter";
import TabSummary from "./TabSummary";
import TabDishes from "./TabDishes";
import TabSlots from "./TabSlots";
import TabTiming from "./TabTiming";

dayjs.locale("ru");

export default function Reports() {
  const [activeTab, setActiveTab] = useState("summary");
  const [startDate, setStartDate] = useState(dayjs().startOf("month"));
  const [endDate, setEndDate] = useState(dayjs());
  const [reportData, setReportData] = useState(null);
  const [dishesStats, setDishesStats] = useState(null);
  const [slotStats, setSlotStats] = useState(null);
  const [timingStartDate, setTimingStartDate] = useState(null);
  const [timingEndDate, setTimingEndDate] = useState(null);

  const generateReport = () => {
    const rawOrders = localStorage.getItem("ordersByDate");
    const rawTimes = localStorage.getItem("timeByDate");

    if (!rawOrders) {
      setReportData(null);
      setDishesStats(null);
      setSlotStats(null);
      setTimingStartDate(null);
      setTimingEndDate(null);
      return;
    }

    const ordersByDate = JSON.parse(rawOrders);
    const timeByDate = rawTimes ? JSON.parse(rawTimes) : {};
    const start = startDate.startOf("day");
    const end = endDate.endOf("day");

    let totalOrders = 0;
    const roomsSet = new Set();
    let toGoCount = 0;
    const dishMap = {};
    const slotMap = {};

    for (const dateKey in ordersByDate) {
      const currentDate = dayjs(dateKey, "YYYY-MM-DD");
      if (!currentDate.isValid() || currentDate.isBefore(start) || currentDate.isAfter(end)) {
        continue;
      }

      const rooms = ordersByDate[dateKey];
      for (const room in rooms) {
        const roomOrders = rooms[room];
        if (!Array.isArray(roomOrders)) continue;

        if (roomOrders.length > 0) {
          roomsSet.add(room);
        }

        const slot = timeByDate?.[dateKey]?.[room] || "—";

        for (const order of roomOrders) {
          totalOrders++;
          if (order.toGo) toGoCount++;

          const allDishes = [
            order.dish1,
            order.dish2,
            order.drinks,
            ...(order.extras || [])
          ];

          for (const item of allDishes) {
            const trimmed = item?.trim();
            if (trimmed) {
              dishMap[trimmed] = (dishMap[trimmed] || 0) + 1;
            }
          }

          slotMap[slot] = (slotMap[slot] || 0) + 1;
        }
      }
    }

    if (activeTab === "summary" || activeTab === "dishes" || activeTab === "slots") {
      if (activeTab === "summary") {
        setReportData({
          totalOrders,
          uniqueRooms: roomsSet.size,
          toGoCount
        });
      }

      if (activeTab === "summary" || activeTab === "dishes") {
        setDishesStats(Object.entries(dishMap).sort((a, b) => b[1] - a[1]));
      }

      if (activeTab === "summary" || activeTab === "slots") {
        setSlotStats(Object.entries(slotMap).sort((a, b) => b[1] - a[1]));
      }
    }

    if (activeTab === "summary" || activeTab === "timing") {
      setTimingStartDate(startDate);
      setTimingEndDate(endDate);
    }
  };

  const tabs = [
    { key: "summary", label: "Общий" },
    { key: "dishes", label: "По блюдам" },
    { key: "slots", label: "По слотам" },
    { key: "timing", label: "Скорость отдачи" }
  ];

  const buttonStyle = {
    padding: "6px 12px",
    fontSize: "14px",
    border: "1px solid #ccc",
    backgroundColor: "#fff",
    borderRadius: "6px",
    cursor: "pointer",
    fontWeight: "500"
  };

  const activeButton = {
    ...buttonStyle,
    backgroundColor: "#eee",
    cursor: "default",
    color: "#666"
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale="ru">
      <div>
        <DateRangeFilter
          startDate={startDate}
          endDate={endDate}
          setStartDate={setStartDate}
          setEndDate={setEndDate}
          onGenerate={generateReport}
        />

        <div style={{ display: "flex", gap: "10px", marginBottom: "16px", flexWrap: "wrap" }}>
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              style={activeTab === tab.key ? activeButton : buttonStyle}
              disabled={activeTab === tab.key}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div style={{ padding: "10px 0" }}>
          {activeTab === "summary" && (
            <>
              <h3>Общая статистика</h3>
              <TabSummary reportData={reportData} />
              <hr style={{ margin: "24px 0" }} />

              <h3>Популярные блюда и напитки</h3>
              <TabDishes dishesStats={dishesStats} />
              <hr style={{ margin: "24px 0" }} />

              <h3>Нагрузка по слотам</h3>
              <TabSlots slotStats={slotStats} />
              <hr style={{ margin: "24px 0" }} />

              <h3>Скорость отдачи</h3>
              <TabTiming startDate={timingStartDate} endDate={timingEndDate} />
            </>
          )}
          {activeTab === "dishes" && <TabDishes dishesStats={dishesStats} />}
          {activeTab === "slots" && <TabSlots slotStats={slotStats} />}
          {activeTab === "timing" && <TabTiming startDate={timingStartDate} endDate={timingEndDate} />}
        </div>
      </div>
    </LocalizationProvider>
  );
}
